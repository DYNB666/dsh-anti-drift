# dsh-anti-drift

> **本插件仅供分享学习，无其他用途。** 请勿用于任何其它目的。
> **For sharing and study only — not for any other purpose.**

一个 DeepSeek Harness（DSH）插件：从引擎层面"防吹牛、防死循环、防原地踏步"，约束 AI 只讲有依据的事实、不瞎编路径/接口/输出、不重复同一动作、不嘴上说说已完成。

## 它做什么（四层防护）

| 层 | 机制 | 作用 |
|---|---|---|
| L0 软引导 | 系统提示词规则段 | 只讲有依据的事实，拿不准就说"不确定"，完成需证据，不空转不复读 |
| L1 硬闸 | `tools/pre-execute` | 拒绝盲改本会话未读过的文件（`edit`）；拒绝 `rm/mv/重定向/sed -i/tee` 等破坏性 shell 命令触碰未取证路径 |
| L2 审计 | `tools/result` + `session/event` | 统计连续"找不到"失败、同一操作重复、猜测式措辞、"声称已完成却无对应成功工具调用" |
| L3 纠偏 | `agent/pre-step` | 越界时在下一步直接向模型注入升级式纠偏消息（提醒→警告→强命令） |

另带一个 UI 小面板（composer 输入框下方）：绿色=正常，黄/红=出现异常，点击看明细。

## 安装

在 DSH 中通过 **Plugins > Add plugin** 选择本目录，或用 `plugin_manager` 的 `install_bundle` 指向本目录。

安装后 Host 日志会打印一行提醒：本插件仅供分享学习，无其他用途。

## 配置（`cordis.patch.yml`）

| 字段 | 默认 | 含义 |
|---|---|---|
| `language` | `auto` | `auto` / `zh` / `en` |
| `strictness` | `standard` | `standard` / `strict` |
| `enforce` | `true` | 总开关；`false` 仅保留提示词层，零额外请求 |
| `blockBlindEdit` | `true` | 拦截对未读文件的盲改 |
| `blockShellWrite` | `true` | 拦截破坏性 shell 命令触碰未读路径 |
| `detectFalseClaims` | `true` | 检测"无据声称完成" |
| `repeatCancelThreshold` | `3` | 同一操作重复几次判定原地打转 |
| `correctionThreshold` | `2` | 连续几次"找不到"触发纠偏 |

## 免责与用途

- **仅供分享学习，无其他用途。**
- 插件只在本地对当前会话的 AI 行为做约束与统计，不额外发起模型请求，不上传数据。
- 启发式命令/措辞识别存在边界（复杂 shell 组合可能识别不到），属正常限制。

## License

MIT（仅供分享学习使用）
